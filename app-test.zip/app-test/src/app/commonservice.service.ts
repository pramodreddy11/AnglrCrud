import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EditdetailsComponent } from './editdetails/editdetails.component';

@Injectable({
  providedIn: 'root'
})
export class CommonserviceService {
  
  Details :any=[
    {
      id:'121032555',
      name :'PramodReddy',
      age :'21',
      address:'hyderabad'
 
    },
    {
     id:'83476234',
     name :'Ram',
     age :21,
     address:'chennai'
 
   },
   {
     id:'644849',
     name :'Manoj',
     age :25,
     address:'mumbai'
 
   }]

   EditDetails:any={}

   geteditDetails(details){
    this.EditDetails.id=details.id;
    this.EditDetails.name=details.name;
    this.EditDetails.age=details.age;
    this.EditDetails.address=details.address;


   }
  constructor(private httprequest: HttpClient) { }
    getJsonData(){
      let url:any='http://dummy.restapiexample.com/api/v1/employees'
      return this.httprequest.get(url);
    }

}
