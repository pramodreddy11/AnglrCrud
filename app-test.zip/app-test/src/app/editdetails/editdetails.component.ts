import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import{CommonserviceService} from '../commonservice.service'

@Component({
  selector: 'app-editdetails',
  templateUrl: './editdetails.component.html',
  styleUrls: ['./editdetails.component.css']
})
export class EditdetailsComponent implements OnInit {
 
  constructor(private commonservice:CommonserviceService,private router:Router) { }
  user:any={
    id:this.commonservice.EditDetails.id,
    name:this.commonservice.EditDetails.name,
    age:this.commonservice.EditDetails.age,
    address:this.commonservice.EditDetails.address

  }
  Details:any=this.commonservice.Details;

  ngOnInit(): void {
  
  }
  onUpdate(form)
  {
    this.commonservice.Details.map((todo, i) => {
      if (todo.id == form.value.id){
        this.commonservice.Details[i] = form.value;
       }
     });
     this.router.navigate(['/crudsmaple'] );
    
  }

}
