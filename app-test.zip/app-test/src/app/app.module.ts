import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CrudappComponent } from './crudapp/crudapp.component';
import {FormsModule} from "@angular/forms";
import { EditdetailsComponent } from './editdetails/editdetails.component';
import { HttpClientModule } from '@angular/common/http';
import { SampledataComponent } from './sampledata/sampledata.component';

@NgModule({
  declarations: [
    AppComponent,
    CrudappComponent,
    EditdetailsComponent,
    SampledataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
