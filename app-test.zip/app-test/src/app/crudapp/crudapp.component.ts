import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import{CommonserviceService} from '../commonservice.service'

@Component({
  selector: 'app-crudapp',
  templateUrl: './crudapp.component.html',
  styleUrls: ['./crudapp.component.css']
})
export class CrudappComponent implements OnInit {
   
 
  constructor( private router: Router, private commonservice:CommonserviceService) {

   }

  Details:any=this.commonservice.Details;

  ngOnInit(): void {
  }
  onSubmit(form) {
    if(form.valid){
    console.log(form);
     let id =form.value.id;
     let name= form.value.id;
     let age =form.value.age;
     let address = form.value.address;
     this.commonservice.Details.push({id:id,name:name,age:age,address:address})
     form.reset();
  }}
  onDelete(detail){
    this.commonservice.Details.map((todo, i) => {
      if (todo.id == detail.id){
        console.log(i);
        this.commonservice.Details.splice(i,1);
       }
     });
  }
  onEdit(details){
    this.commonservice.geteditDetails(details);
   this.router.navigate(['/edit'] );

  }

}
