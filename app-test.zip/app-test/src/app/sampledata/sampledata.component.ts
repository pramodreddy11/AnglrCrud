import { Component, OnInit } from '@angular/core';
import{CommonserviceService} from '../commonservice.service'

@Component({
  selector: 'app-sampledata',
  templateUrl: './sampledata.component.html',
  styleUrls: ['./sampledata.component.css']
})
export class SampledataComponent implements OnInit {

  constructor(private commonservice :CommonserviceService) { }
  Data :any=[];
 
  ngOnInit(): void {
    this.commonservice.getJsonData().subscribe((response: any) => {
      console.log(response);
      this.Data=response.data;
    })
  }
  
 
   
}
